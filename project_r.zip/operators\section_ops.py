from __future__ import annotations

import datetime as dt
import json
import math
from pathlib import Path
from typing import List, Tuple

import bpy
import bmesh
import numpy as np
import random

from .. import deps
from .. import erosion
from .. import geo
from .. import imaging
from .. import layers
from .. import manifest as manifest_lib
from ..projection_backend import ProjectionParams, project_equirect_to_hammer, project_equirect_array_to_hammer
from . import sphere_ops


def _get_pp():
    """Lazy import of projectionpasta to allow addon to load even if PIL is missing."""
    from ..vendor.projectionpasta import projectionpasta as pp  # type: ignore
    return pp


def _point_in_triangle_2d(
    px: np.ndarray,
    py: np.ndarray,
    ax: float, ay: float,
    bx: float, by: float,
    cx: float, cy: float,
) -> np.ndarray:
    """
    Vectorized check if points (px, py) are inside triangle ABC.
    Returns boolean mask.
    """
    def sign(p1x, p1y, p2x, p2y, p3x, p3y):
        return (p1x - p3x) * (p2y - p3y) - (p2x - p3x) * (p1y - p3y)

    d1 = sign(px, py, ax, ay, bx, by)
    d2 = sign(px, py, bx, by, cx, cy)
    d3 = sign(px, py, cx, cy, ax, ay)

    has_neg = (d1 < 0) | (d2 < 0) | (d3 < 0)
    has_pos = (d1 > 0) | (d2 > 0) | (d3 > 0)

    return ~(has_neg & has_pos)


def _rasterize_coverage_mask(
    *,
    triangles_uv: List[Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float]]],
    center: geo.LonLat,
    rot_rad: float,
    full_size: Tuple[int, int],
    crop_rect: geo.RectI,
    half_res: bool = True,
) -> np.ndarray:
    """
    Rasterize selected face triangles into a coverage mask in Hammer crop space.
    
    For each pixel in the crop:
    1. Compute its Hammer x,y coordinates
    2. Inverse-project to lon/lat
    3. Convert to equirect UV
    4. Check if inside any selected triangle
    
    Returns: (H, W) float32 array with 1.0 where selected, 0.0 elsewhere.
    """
    pp = _get_pp()  # Lazy import
    full_w, full_h = full_size
    cx, cy, cw, ch = crop_rect.x, crop_rect.y, crop_rect.w, crop_rect.h

    # Output size (half res if requested)
    if half_res:
        out_w, out_h = cw // 2, ch // 2
    else:
        out_w, out_h = cw, ch

    if out_w <= 0 or out_h <= 0:
        return np.zeros((max(1, out_h), max(1, out_w)), dtype=np.float32)

    # Create pixel grid for the crop
    # Map crop pixel coords to full canvas coords, then to Hammer projection coords
    crop_x = np.linspace(0.5, out_w - 0.5, out_w, dtype=np.float64)
    crop_y = np.linspace(0.5, out_h - 0.5, out_h, dtype=np.float64)
    crop_xx, crop_yy = np.meshgrid(crop_x, crop_y)

    # Scale crop coords to full canvas coords
    if half_res:
        full_xx = cx + crop_xx * 2.0
        full_yy = cy + crop_yy * 2.0
    else:
        full_xx = cx + crop_xx
        full_yy = cy + crop_yy

    # Convert full canvas pixel coords to Hammer projection space [-1, 1]
    hammer_x = (full_xx + 0.5) / full_w * 2.0 - 1.0
    hammer_y = 1.0 - (full_yy + 0.5) / full_h * 2.0

    # Inverse Hammer projection: get lon/lat from hammer_x, hammer_y
    # Using projectionpasta's inverse projection
    opts = dict(pp.def_opts)
    opts["in"] = True  # inverse direction

    aspect = np.array([center.lon, center.lat, rot_rad], dtype=np.float64)

    # projectionpasta Hammer inverse: x,y -> lon,lat
    lon_r, lat_r = pp.posl["Hammer"](hammer_x.ravel(), hammer_y.ravel(), opts)

    # Rotate back from centered coords
    lon, lat = pp.Rotate_from(lon_r, lat_r, aspect)

    lon = lon.reshape(out_h, out_w)
    lat = lat.reshape(out_h, out_w)

    # Check which pixels are outside valid Hammer projection (NaN or outside range)
    valid_proj = np.isfinite(lon) & np.isfinite(lat)

    # Convert lon/lat to UV
    # lon in radians: -pi..pi -> U 0..1
    # lat in radians: -pi/2..pi/2 -> V 0..1
    u = (lon / (2 * np.pi) + 0.5) % 1.0
    v = (lat / np.pi + 0.5)

    # Now check if each UV point falls inside any selected triangle
    mask = np.zeros((out_h, out_w), dtype=np.float32)

    for tri in triangles_uv:
        (u0, v0), (u1, v1), (u2, v2) = tri

        # Handle seam-crossing triangles
        us = [u0, u1, u2]
        span = max(us) - min(us)

        if span > 0.5:
            # Triangle crosses U seam; test both shifted versions
            # Variant A: shift low U values up
            tri_a = [(uu + 1.0 if uu < 0.5 else uu, vv) for (uu, vv) in tri]
            # Variant B: shift high U values down
            tri_b = [(uu - 1.0 if uu > 0.5 else uu, vv) for (uu, vv) in tri]

            # Test shifted UVs
            u_shifted_a = np.where(u < 0.5, u + 1.0, u)
            u_shifted_b = np.where(u > 0.5, u - 1.0, u)

            inside_a = _point_in_triangle_2d(
                u_shifted_a, v,
                tri_a[0][0], tri_a[0][1],
                tri_a[1][0], tri_a[1][1],
                tri_a[2][0], tri_a[2][1],
            )
            inside_b = _point_in_triangle_2d(
                u_shifted_b, v,
                tri_b[0][0], tri_b[0][1],
                tri_b[1][0], tri_b[1][1],
                tri_b[2][0], tri_b[2][1],
            )
            inside = inside_a | inside_b
        else:
            inside = _point_in_triangle_2d(
                u, v,
                u0, v0,
                u1, v1,
                u2, v2,
            )

        mask = np.where(inside & valid_proj, 1.0, mask)

    return mask.astype(np.float32)


def _selected_uv_lonlats(context: bpy.types.Context) -> List[geo.LonLat]:
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return []
    if context.mode != "EDIT_MESH":
        return []
    me = obj.data
    uv_layer = me.uv_layers.active
    if uv_layer is None:
        return []

    bm = bmesh.from_edit_mesh(me)
    uv = bm.loops.layers.uv.active
    if uv is None:
        return []

    pts: List[geo.LonLat] = []
    for f in bm.faces:
        if not f.select:
            continue
        for loop in f.loops:
            u, v = loop[uv].uv
            pts.append(geo.uv_to_lonlat(float(u), float(v)))
    return pts


def _selected_face_indices(context: bpy.types.Context) -> List[int]:
    obj = context.active_object
    if obj is None or obj.type != "MESH":
        return []
    if context.mode != "EDIT_MESH":
        return []
    bm = bmesh.from_edit_mesh(obj.data)
    return [int(f.index) for f in bm.faces if f.select]


def _grow_faces(seed: set[bmesh.types.BMFace], rings: int) -> set[bmesh.types.BMFace]:
    rings = max(0, int(rings))
    grown: set[bmesh.types.BMFace] = set(seed)
    frontier: set[bmesh.types.BMFace] = set(seed)
    for _ in range(rings):
        new_frontier: set[bmesh.types.BMFace] = set()
        for f in frontier:
            for e in f.edges:
                for nb in e.link_faces:
                    if nb not in grown:
                        grown.add(nb)
                        new_frontier.add(nb)
        frontier = new_frontier
        if not frontier:
            break
    return grown


def _gather_uv_triangles_for_faces(
    bm: bmesh.types.BMesh,
    faces: set[bmesh.types.BMFace],
    uv_layer,
) -> list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]]:
    tris: list[tuple[tuple[float, float], tuple[float, float], tuple[float, float]]] = []
    for f in faces:
        loops = list(f.loops)
        if len(loops) < 3:
            continue
        u0, v0 = loops[0][uv_layer].uv
        p0 = (float(u0), float(v0))
        for i in range(1, len(loops) - 1):
            u1, v1 = loops[i][uv_layer].uv
            u2, v2 = loops[i + 1][uv_layer].uv
            tris.append((p0, (float(u1), float(v1)), (float(u2), float(v2))))
    return tris


def _face_uv_center(loop_uvs: list[tuple[float, float]]) -> tuple[float, float]:
    us = [u for (u, _) in loop_uvs]
    vs = [v for (_, v) in loop_uvs]
    if not us:
        return (0.0, 0.0)
    if max(us) - min(us) > 0.5:
        # Seam-crossing face: shift low-u up for averaging.
        us2 = [u + (1.0 if u < 0.5 else 0.0) for u in us]
        u = (sum(us2) / len(us2)) % 1.0
    else:
        u = (sum(us) / len(us)) % 1.0
    v = sum(vs) / len(vs)
    return (u, v)


def _gather_uv_centers_for_faces(
    bm: bmesh.types.BMesh,
    faces: set[bmesh.types.BMFace],
    uv_layer,
) -> list[tuple[float, float]]:
    centers: list[tuple[float, float]] = []
    for f in faces:
        luv = []
        for loop in f.loops:
            u, v = loop[uv_layer].uv
            luv.append((float(u), float(v)))
        centers.append(_face_uv_center(luv))
    return centers


# ---------------------------------------------------------------------------
# Wilbur Guidance Helpers
# ---------------------------------------------------------------------------

def _clamp_int(x: float, lo: int, hi: int) -> int:
    """Clamp and round a float to an integer within [lo, hi]."""
    return max(lo, min(hi, round(x)))


def _pick_wilbur_preset(extent_km: float) -> dict:
    """
    Select Wilbur erosion preset based on tile width in km.
    
    Returns a dict with:
      - name: preset name
      - target_smoothing_km: Incise Flow pre-blur target in km
      - target_major_km: Major river reinforcement pre-blur target in km
      - incise_amount: Incise Flow Amount parameter
      - incise_exponent: Incise Flow Exponent parameter
      - precip_delta: Precipitation erosion delta
      - precip_iters_low: Minimum recommended iterations
      - precip_iters_high: Maximum recommended iterations
    """
    if extent_km < 500:
        return {
            "name": "LOCAL",
            "target_smoothing_km": 2.0,
            "target_major_km": 0.8,
            "incise_amount": 0.35,
            "incise_exponent": 0.45,
            "precip_delta": 0.03,
            "precip_iters_low": 35,
            "precip_iters_high": 55,
        }
    elif extent_km < 1500:
        return {
            "name": "REGIONAL",
            "target_smoothing_km": 5.0,
            "target_major_km": 2.0,
            "incise_amount": 0.5,
            "incise_exponent": 0.4,
            "precip_delta": 0.02,
            "precip_iters_low": 30,
            "precip_iters_high": 45,
        }
    elif extent_km < 4000:
        return {
            "name": "CONTINENTAL",
            "target_smoothing_km": 10.0,
            "target_major_km": 3.5,
            "incise_amount": 0.6,
            "incise_exponent": 0.4,
            "precip_delta": 0.02,
            "precip_iters_low": 30,
            "precip_iters_high": 40,
        }
    else:
        return {
            "name": "SUPERCONTINENTAL",
            "target_smoothing_km": 20.0,
            "target_major_km": 6.0,
            "incise_amount": 0.7,
            "incise_exponent": 0.35,
            "precip_delta": 0.015,
            "precip_iters_low": 20,
            "precip_iters_high": 35,
        }


def _compute_affine_mapping(
    max_elev_m: float,
    min_elev_m: float = 0.0,
    wilbur_min: float = 500.0,
    wilbur_max: float = 3500.0,
) -> Tuple[float, float]:
    """
    Compute affine mapping from metres to Wilbur units.
    
    Returns (scale, offset) such that:
      h_wilbur = h_metres * scale + offset
      h_metres = (h_wilbur - offset) / scale
    
    If max_elev_m <= min_elev_m, returns identity-like (1.0, wilbur_min).
    """
    elev_range = max_elev_m - min_elev_m
    if elev_range <= 0:
        # Fallback: no valid range, use identity-like mapping
        return (1.0, wilbur_min)
    
    scale = (wilbur_max - wilbur_min) / elev_range
    offset = wilbur_min - min_elev_m * scale
    return (scale, offset)


def _write_section_info_txt(
    *,
    section_dir: Path,
    section_name: str,
    created_utc: str,
    planet_radius_km: float,
    extent_km: Tuple[float, float],
    km_per_pixel: float,
    projection_type: str,
    center_lon_deg: float,
    center_lat_deg: float,
    rot_deg: float,
    crop_pixels: Tuple[int, int],
    crop_position: Tuple[int, int],
    full_canvas_size: Tuple[int, int],
    square_crop: bool,
    feather_px: int,
    elevation_info: dict | None = None,
) -> None:
    """Write a human-readable section_info.txt file."""
    info_path = section_dir / "section_info.txt"
    
    lines = [
        f"Section: {section_name}",
        f"Created: {created_utc}",
        "",
        "=== Physical Size ===",
        f"Planet Radius: {planet_radius_km:.0f} km",
        f"Extent: {extent_km[0]:.1f} x {extent_km[1]:.1f} km",
        f"Resolution: {km_per_pixel:.2f} km/pixel",
        "",
        "=== Projection ===",
        f"Type: {projection_type}",
        f"Center: {center_lon_deg:.2f}° lon, {center_lat_deg:.2f}° lat",
        f"Rotation: {rot_deg:.1f}°",
        "",
        "=== Crop ===",
        f"Pixels: {crop_pixels[0]} x {crop_pixels[1]}",
        f"Position: ({crop_position[0]}, {crop_position[1]}) in full canvas",
        f"Full Canvas: {full_canvas_size[0]} x {full_canvas_size[1]}",
        f"Square Crop: {'Yes' if square_crop else 'No'}",
        f"Feather: {feather_px} px",
    ]
    
    # Add elevation info if available
    if elevation_info is not None:
        max_brightness = elevation_info.get("section_max_brightness", 0)
        min_brightness = elevation_info.get("section_min_brightness", 0)
        section_max_elev = elevation_info.get("section_max_elevation_m", 0)
        section_min_elev = elevation_info.get("section_min_elevation_m", 0)
        heightmap_file = elevation_info.get("heightmap_file", "")
        
        lines.extend([
            "",
            "=== Elevation ===",
            f"Heightmap: {heightmap_file}",
            f"Brightness Range: {min_brightness:.2f}-{max_brightness:.2f} ({min_brightness*100:.0f}%-{max_brightness*100:.0f}%)",
            f"Elevation Range: {section_min_elev:.0f}-{section_max_elev:.0f} m",
        ])
    
    # Calculate Gaea suggestions
    max_extent_km = max(extent_km)
    gaea_max_scale_km = 2400.0
    
    lines.extend([
        "",
        "=== For Gaea ===",
    ])
    
    if max_extent_km <= gaea_max_scale_km:
        lines.append(f"Map Size: {max_extent_km:.0f} km")
        if elevation_info is not None:
            section_elev = elevation_info.get("section_max_elevation_m", 0)
            lines.append(f"Suggested Height: {section_elev:.0f} m")
        else:
            lines.append(f"(Set height based on your heightmap's max elevation)")
    else:
        # Section exceeds Gaea's limit - need to scale down
        scale_factor = gaea_max_scale_km / max_extent_km
        lines.append(f"Map Size: {max_extent_km:.0f} km (exceeds Gaea's {gaea_max_scale_km:.0f} km limit)")
        lines.append(f"Use Gaea Map Size: {gaea_max_scale_km:.0f} km")
        
        if elevation_info is not None:
            section_elev = elevation_info.get("section_max_elevation_m", 0)
            scaled_height = section_elev * scale_factor
            lines.extend([
                f"Suggested Height: {scaled_height:.0f} m (scaled from {section_elev:.0f} m)",
                "",
                f"Calculation: {section_elev:.0f} m × ({gaea_max_scale_km:.0f} / {max_extent_km:.0f}) = {scaled_height:.0f} m",
                "This maintains the correct height-to-width ratio in Gaea.",
            ])
        else:
            lines.extend([
                "",
                f"Scale your height by {scale_factor:.2f}x to maintain proportions.",
                f"Example: 8849 m × {scale_factor:.2f} = {8849 * scale_factor:.0f} m",
            ])
    
    # === For Wilbur === section
    extent_width_km = extent_km[0]
    crop_width_px = crop_pixels[0]
    
    # Guard against division by zero
    if extent_width_km <= 0 or crop_width_px <= 0:
        lines.extend([
            "",
            "=== For Wilbur ===",
            "(Wilbur guidance unavailable - invalid extent or crop size)",
        ])
        info_path.write_text("\n".join(lines), encoding="utf-8")
        return
    
    km_per_px = extent_width_km / crop_width_px
    px_per_km = crop_width_px / extent_width_km
    
    # Pick preset based on extent
    preset = _pick_wilbur_preset(extent_width_km)
    pre_blur_px = _clamp_int(preset["target_smoothing_km"] * px_per_km, 2, 96)
    pre_blur_major_px = _clamp_int(preset["target_major_km"] * px_per_km, 2, 64)
    
    # Affine mapping for height conversion
    max_elev_m = elevation_info.get("section_max_elevation_m", 0) if elevation_info else 0
    min_elev_m = elevation_info.get("section_min_elevation_m", 0) if elevation_info else 0
    wilbur_min, wilbur_max = 500.0, 3500.0
    
    # Use actual min if available and non-zero, otherwise assume sea level
    use_fallback = (min_elev_m == 0 and max_elev_m > 0)
    scale, offset = _compute_affine_mapping(max_elev_m, min_elev_m, wilbur_min, wilbur_max)
    
    lines.extend([
        "",
        "=== For Wilbur ===",
        f"Preset: {preset['name']} (extent {extent_width_km:.1f} km)",
        f"Scale: {km_per_px:.2f} km/px | {px_per_km:.2f} px/km",
        "",
        f"--- Height Mapping (Span {wilbur_min:.0f}-{wilbur_max:.0f}) ---",
        "Note: Wilbur 'Span' is NOT metres. Use this affine mapping for consistency.",
        f"To convert metres -> Wilbur units: h_w = h_m * {scale:.6g} + {offset:.6g}",
        f"To convert Wilbur -> metres: h_m = (h_w - {offset:.6g}) / {scale:.6g}",
    ])
    if use_fallback:
        lines.append("(Fallback assumes sea level ~0; relative shapes remain correct)")
    
    lines.extend([
        "",
        "--- Recipe (do in order) ---",
        "",
        "(1) Fill Basins",
        "    Filter -> Fill -> Fill Basins",
        "",
        "(2) Incise Flow (drainage topology)",
        "    Filter -> Erosion -> Incise Flow...",
        f"    Amount: {preset['incise_amount']}",
        f"    Flow Exponent: {preset['incise_exponent']}",
        "    Effect Blend: 1",
        f"    Pre Blur (sigma): {pre_blur_px}",
        "    Variable Blur: 0",
        "    Post Blur: 0",
        "    Run ONCE.",
        "",
        "(3) Precipitation-Based erosion (broad valleys)",
        "    Filter -> Erosion -> Precipitation-Based... (Ctrl+E)",
        f"    Delta: {preset['precip_delta']}",
        "    Max Length: -1",
        "    Connectivity: 8 way",
        "    Wrap: None",
        "    Use Only Selection: OFF (IMPORTANT)",
        "    Sea: Ignore",
        "    Hardness: 0.5",
        "    Passes: 1",
        "    Blend: None",
        "    Noise: None",
        f"    Iterations: {preset['precip_iters_low']}-{preset['precip_iters_high']}",
        "",
        "(4) Fill Basins again",
        "    Filter -> Fill -> Fill Basins",
        "",
        "(5) Optional floodplain micro-relief (if basins too flat)",
        "    Filter -> Noise -> Absolute Magnitude Noise...",
        "    Magnitude: 1.5 (range 1.0-2.0), Additive: ON",
        "    Then: Fill Basins",
        "    Optional soften: Precip Delta 0.005-0.01, Iters 10-15",
        "",
        "(6) Optional major-river reinforcement",
        "    Filter -> Erosion -> Incise Flow...",
        "    Amount: 0.3",
        "    Flow Exponent: 0.6",
        f"    Pre Blur (sigma): {pre_blur_major_px}",
        "    Effect Blend: 1",
        "    Variable Blur: 0",
        "    Post Blur: 0",
    ])
    
    # Upscaled suggestions
    upscaled_lines = ["", "--- Upscaled Suggestions (same km extent) ---"]
    for res in [4096, 8192]:
        km_per_px_up = extent_width_km / res
        px_per_km_up = res / extent_width_km
        pre_blur_up = _clamp_int(preset["target_smoothing_km"] * px_per_km_up, 2, 96)
        pre_blur_major_up = _clamp_int(preset["target_major_km"] * px_per_km_up, 2, 64)
        upscaled_lines.append(
            f"{res}: {km_per_px_up:.2f} km/px | {px_per_km_up:.2f} px/km | "
            f"Incise PreBlur: {pre_blur_up} | Major PreBlur: {pre_blur_major_up}"
        )
    lines.extend(upscaled_lines)
    
    info_path.write_text("\n".join(lines), encoding="utf-8")


def _compute_crop_rect(
    *,
    lonlats: List[geo.LonLat],
    center: geo.LonLat,
    rot_rad: float,
    full_size: Tuple[int, int],
    margin_px: int,
    square: bool,
) -> geo.RectI:
    pp = _get_pp()  # Lazy import
    w, h = full_size
    # IMPORTANT: Use projectionpasta's own forward projection for Hammer so
    # crop bounds match exactly what we render in hammer_full.
    lons = np.array([p.lon for p in lonlats], dtype=np.float64)
    lats = np.array([p.lat for p in lonlats], dtype=np.float64)

    aspect = np.array([center.lon, center.lat, rot_rad], dtype=np.float64)
    lon_r, lat_r = pp.Rotate_to(lons, lats, aspect)

    opts = dict(pp.def_opts)
    opts["in"] = False
    x, y = pp.posl["Hammer"](lon_r, lat_r, opts)  # x,y are in [-1,1]

    xs = ((x + 1.0) / 2.0 * w - 0.5).tolist()
    ys = ((1.0 - y) / 2.0 * h - 0.5).tolist()

    if not xs:
        return geo.RectI(0, 0, w, h)

    x0 = int(math.floor(min(xs))) - margin_px
    y0 = int(math.floor(min(ys))) - margin_px
    x1 = int(math.ceil(max(xs))) + 1 + margin_px
    y1 = int(math.ceil(max(ys))) + 1 + margin_px

    x0 = max(0, min(x0, w - 1))
    y0 = max(0, min(y0, h - 1))
    x1 = max(1, min(x1, w))
    y1 = max(1, min(y1, h))

    rect = geo.RectI(x=x0, y=y0, w=max(1, x1 - x0), h=max(1, y1 - y0))
    if square:
        rect = geo.expand_rect_square(rect, w, h)
    return rect


class PP_OT_create_section(bpy.types.Operator):
    bl_idname = "pp.create_section"
    bl_label = "Create Section"
    bl_description = "Create a Hammer (oblique) section crop from the selected faces and record it in manifest.json"

    @classmethod
    def poll(cls, context: bpy.types.Context) -> bool:
        if context.mode != "EDIT_MESH":
            cls.poll_message_set("Enter Edit Mode on the sphere and select the faces to export")
            return False
        s = getattr(context.scene, "projection_pasta", None)
        mp = s.manifest_path() if s is not None else None
        if mp is None or not mp.exists():
            cls.poll_message_set("Open or create a project first")
            return False
        return True

    def execute(self, context: bpy.types.Context):
        s = context.scene.projection_pasta
        root = s.project_root_path()
        mp = s.manifest_path()
        if root is None or mp is None:
            self.report({"ERROR"}, "Project Root is not set")
            return {"CANCELLED"}
        if not mp.exists():
            self.report({"ERROR"}, "manifest.json does not exist (run Init Project)")
            return {"CANCELLED"}

        lonlats = _selected_uv_lonlats(context)
        if len(lonlats) < 3:
            self.report({"ERROR"}, "Select some faces on the sphere in Edit Mode")
            return {"CANCELLED"}

        face_indices = _selected_face_indices(context)

        # Gather UV triangles NOW while bmesh is definitely valid (for coverage mask later)
        selected_triangles_uv: List[Tuple[Tuple[float, float], Tuple[float, float], Tuple[float, float]]] = []
        try:
            obj = context.active_object
            if obj is not None and obj.type == "MESH" and context.mode == "EDIT_MESH":
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is not None:
                    seed_faces = {f for f in bm.faces if f.select}
                    selected_triangles_uv = _gather_uv_triangles_for_faces(bm, seed_faces, uv_layer)
        except Exception:
            selected_triangles_uv = []
        
        # Compute center: use override if enabled, otherwise auto-compute from selection
        if s.override_projection_center:
            center = geo.LonLat(
                lon=math.radians(s.override_center_lon),
                lat=math.radians(s.override_center_lat)
            )
            print(f"[Project-R] Using override center: {s.override_center_lon:.2f}° lon, {s.override_center_lat:.2f}° lat")
        else:
            center = geo.mean_center_lonlat(lonlats)
        
        params = ProjectionParams(
            center_lon_deg=math.degrees(center.lon),
            center_lat_deg=math.degrees(center.lat),
            rot_deg=0.0,
        )

        # Compute lon/lat bounds for physical extent calculation
        min_lon_deg, max_lon_deg, min_lat_deg, max_lat_deg = geo.compute_lonlat_bounds(lonlats)
        lon_range_deg = max_lon_deg - min_lon_deg
        lat_range_deg = max_lat_deg - min_lat_deg
        
        # Handle dateline crossing (lon range > 180 means we crossed the -180/180 boundary)
        if lon_range_deg > 180.0:
            lon_range_deg = 360.0 - lon_range_deg
        
        # Get planet radius from settings
        planet_radius_km = s.planet_radius_km

        manifest = manifest_lib.read_manifest(mp)
        global_size = manifest.get("global", {}).get("size", [0, 0])
        if not global_size or global_size[0] <= 0 or global_size[1] <= 0:
            self.report({"ERROR"}, "Global size not set. Use Load World Map first.")
            return {"CANCELLED"}

        sec_id = f"sec_{len(manifest.get('sections', [])) + 1:03d}_{s.new_section_name.lower()}"
        sec_dir = root / "sections" / sec_id
        proc_dir = root / "processed" / sec_id
        # Track which dirs we actually create here, so failure-cleanup only removes
        # our own work and never deletes a pre-existing section's data that happens
        # to collide on this count-based id (e.g. after a manual manifest reset).
        created_dirs = [d for d in (sec_dir, proc_dir) if not d.exists()]
        sec_dir.mkdir(parents=True, exist_ok=True)
        proc_dir.mkdir(parents=True, exist_ok=True)

        # ---- Update extracted overlay (per-section color) ----
        try:
            obj = context.active_object
            if obj is not None and obj.type == "MESH" and context.mode == "EDIT_MESH":
                bm = bmesh.from_edit_mesh(obj.data)
                uv_layer = bm.loops.layers.uv.active
                if uv_layer is not None:
                    seed_faces = {f for f in bm.faces if f.select}
                    # Only show actually selected faces in overlay (not grown)
                    centers_uv = _gather_uv_centers_for_faces(bm, seed_faces, uv_layer)

                    # Deterministic per-section color
                    rr = random.Random(sec_id)
                    col = (
                        int(80 + rr.random() * 175),
                        int(80 + rr.random() * 175),
                        int(80 + rr.random() * 175),
                        160,  # alpha
                    )

                    overlay_rel = "project_r_overlay.png"
                    overlay_path = (root / overlay_rel).resolve()
                    ow, oh = int(global_size[0]), int(global_size[1])
                    overlay = imaging.load_or_create_overlay_rgba_u8(overlay_path, (ow, oh))
                    # Draw markers at face centers instead of filling faces.
                    radius_px = max(2, int(min(ow, oh) / 512))
                    overlay = imaging.paint_uv_circles_on_overlay(
                        overlay,
                        centers_uv=centers_uv,
                        radius_px=radius_px,
                        color_rgba_u8=col,
                    )
                    imaging.save_overlay_rgba_u8(overlay_path, overlay)

                    manifest.setdefault("global", {})["overlay"] = {
                        "path": overlay_rel,
                        "size": [ow, oh],
                    }

                    # If the overlay image is loaded in Blender, reload it so it updates on the sphere.
                    for img in bpy.data.images:
                        try:
                            fp = bpy.path.abspath(img.filepath_raw)
                        except Exception:
                            fp = img.filepath_raw
                        if fp and Path(fp).resolve() == overlay_path:
                            img.reload()
                            break

                    overlay_color_rgba = [c / 255.0 for c in col]
                else:
                    overlay_color_rgba = None
            else:
                overlay_color_rgba = None
        except Exception:
            overlay_color_rgba = None
        else:
            # If we created/updated overlay info, ensure the sphere material is wired to show it.
            try:
                if "overlay_path" in locals():
                    sphere_ops.ensure_overlay_connected_with_paths(context, overlay_path=overlay_path)
                else:
                    sphere_ops.ensure_overlay_connected(context)
            except Exception:
                pass

        # Use the world map size for Hammer full dimensions
        full_w = int(global_size[0])
        full_h = int(global_size[1])
        # Use feather_px as the crop margin (no separate crop margin setting)
        rect = _compute_crop_rect(
            lonlats=lonlats,
            center=center,
            rot_rad=0.0,
            full_size=(full_w, full_h),
            margin_px=int(s.feather_px),
            square=bool(s.square_crop),
        )

        # Compute physical extent in kilometers
        extent_width_km, extent_height_km = geo.compute_section_extent_km(
            center_lon_deg=math.degrees(center.lon),
            center_lat_deg=math.degrees(center.lat),
            lon_range_deg=lon_range_deg,
            lat_range_deg=lat_range_deg,
            planet_radius_km=planet_radius_km,
        )
        
        # Calculate km per pixel for the crop
        # Use the larger dimension for a consistent scale reference
        crop_diagonal_px = math.sqrt(rect.w**2 + rect.h**2)
        extent_diagonal_km = math.sqrt(extent_width_km**2 + extent_height_km**2)
        km_per_pixel = extent_diagonal_km / crop_diagonal_px if crop_diagonal_px > 0 else 0.0

        # Scan source/ folder for all image files to process
        source_dir = root / "source"
        IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".exr", ".tif", ".tiff"}
        source_maps: List[Path] = []
        
        # Include the world map first (if it exists and isn't already in source/)
        world_map_info = manifest.get("global", {}).get("world_map", {})
        world_map_path = manifest_lib.resolve_source_path(root, world_map_info.get("path", ""))
        if world_map_path is not None and world_map_path.suffix.lower() in IMAGE_EXTENSIONS:
            source_maps.append(world_map_path)
        
        # Add all maps from source/ folder
        if source_dir.exists():
            for f in source_dir.iterdir():
                if f.is_file() and f.suffix.lower() in IMAGE_EXTENSIONS:
                    # Avoid duplicates if world map is in source/
                    if f.resolve() not in [p.resolve() for p in source_maps]:
                        source_maps.append(f)
        
        full_paths: dict[str, str] = {}
        crop_paths: dict[str, str] = {}

        print(f"[Project-R] Processing {len(source_maps)} source map(s)...")

        # Reprojecting every source map is the slow, blocking part. Show an honest
        # busy cursor + status-bar progress, and on failure remove the partial
        # section folders and report cleanly instead of throwing raw mid-write and
        # leaving an orphan section directory with no manifest entry.
        # Output resolution for exported crops (longest edge). AUTO follows the global
        # World Map Resolution target: with a target set, each section is exported at its
        # share of it (native x target/world); with the target on 'Auto' (world size) AUTO
        # keeps the native crop size (full source detail). An explicit size wins.
        native_long = max(int(rect.w), int(rect.h))
        world_long = max(int(full_w), int(full_h))
        tgt = str(s.target_world_resolution)
        if str(s.output_resolution) != "AUTO":
            try:
                export_res = int(s.output_resolution)
            except (TypeError, ValueError):
                export_res = native_long
        elif tgt in ("AUTO", "", "WORLD"):
            export_res = native_long
        else:
            target_long = erosion.resolve_world_resolution(tgt, world_long)
            export_res = max(64, int(round(native_long * target_long / max(world_long, 1))))

        win = context.window
        wm = context.window_manager
        win.cursor_set("WAIT")
        wm.progress_begin(0, max(1, len(source_maps)))
        try:
            for i, src_path in enumerate(source_maps):
                wm.progress_update(i)
                filename = src_path.name
                layer_id = src_path.stem  # filename without extension
                ext = src_path.suffix.lower()

                full_rel = Path("sections") / sec_id / f"{filename.replace(ext, '')}__hammer_full{ext}"
                crop_rel = Path("sections") / sec_id / "crops" / filename
                full_path = (root / full_rel).resolve()
                crop_path = (root / crop_rel).resolve()
                crop_path.parent.mkdir(parents=True, exist_ok=True)

                interp = layers.interp_for_layer(filename)
                treat_as_color = layers.treat_as_color(filename)

                print(f"[Project-R]   - {filename} (interp={interp}, color={treat_as_color})")

                project_equirect_to_hammer(
                    src_path=src_path,
                    dst_path=full_path,
                    dst_size=(full_w, full_h),
                    params=params,
                    interp=interp,  # type: ignore[arg-type]
                    treat_as_color=treat_as_color,
                )

                full_img = imaging.load_image(full_path)
                crop_img = imaging.crop(full_img, rect.x, rect.y, rect.w, rect.h)
                # Resample to the chosen output resolution (longest edge), preserving
                # aspect and the layer's interpolation (nearest for masks).
                if export_res != native_long and native_long > 0:
                    sc = export_res / float(native_long)
                    nw = max(1, int(round(rect.w * sc)))
                    nh = max(1, int(round(rect.h * sc)))
                    rp = imaging.resize_to(crop_img.pixels, nw, nh, interp=interp)
                    if rp.ndim == 2:
                        rp = rp[..., None]
                    crop_img = imaging.ImageBuffer(width=nw, height=nh, channels=rp.shape[2], pixels=rp)
                # Save crop with same format as full_path
                fmt, depth = (
                    ("OPEN_EXR", "32")
                    if ext == ".exr"
                    else ("PNG", "8" if treat_as_color else "16")
                    if ext == ".png"
                    else ("JPEG", None)
                )
                imaging.save_image(crop_img, crop_path, fmt, color_depth=depth)

                full_paths[layer_id] = str(full_rel).replace("\\", "/")
                crop_paths[filename] = str(crop_rel).replace("\\", "/")
        except Exception as e:
            import traceback
            import shutil
            traceback.print_exc()
            for d in created_dirs:
                shutil.rmtree(d, ignore_errors=True)
            self.report({"ERROR"}, f"Failed to build section '{s.new_section_name}': {e}")
            return {"CANCELLED"}
        finally:
            wm.progress_end()
            win.cursor_set("DEFAULT")

        # ---- Generate Effective Mask ----
        # New approach: create mask in equirect space, reproject to Hammer, then crop
        # This ensures the mask goes through the same projection as the images
        
        # 1. Create solid mask in equirect space (same size as world map)
        equirect_mask = imaging.create_solid_mask_equirect(
            width=int(global_size[0]),
            height=int(global_size[1]),
            triangles_uv=selected_triangles_uv,
        )
        print(f"[Project-R] Equirect mask created: {equirect_mask.shape}, coverage={np.sum(equirect_mask > 0.5)}")
        
        # 2. Reproject equirect mask to Hammer space (full canvas)
        hammer_mask_full = project_equirect_array_to_hammer(
            data_in=equirect_mask[..., None],  # Add channel dim
            dst_size=(full_w, full_h),
            params=params,
            interp="linear",
            treat_as_color=False,
        )
        hammer_mask_full = hammer_mask_full[:, :, 0]  # Remove channel dim
        print(f"[Project-R] Hammer mask (full): {hammer_mask_full.shape}, coverage={np.sum(hammer_mask_full > 0.5)}")
        
        # 3. Crop to section bounds
        x, y, w_crop, h_crop = rect.x, rect.y, rect.w, rect.h
        coverage_mask_crop = hammer_mask_full[y:y+h_crop, x:x+w_crop]
        
        # 4. Downsample to half-res for mask storage
        coverage_half = imaging.resize_half(coverage_mask_crop)
        
        # 5. Apply feathering (scale feather_px for half-res)
        effective_mask = imaging.generate_effective_mask(
            coverage_half,
            feather_px=int(s.feather_px) // 2,
        )
        effective_rel = Path("sections") / sec_id / "effective_mask__crop.png"
        effective_path = root / effective_rel
        effective_buf = imaging.ImageBuffer(
            width=effective_mask.shape[1],
            height=effective_mask.shape[0],
            channels=1,
            pixels=effective_mask[..., None],
        )
        imaging.save_image(effective_buf, effective_path, "PNG", color_depth="16")

        # ---- Heightmap Elevation Tracking ----
        elevation_info: dict | None = None
        heightmap_filename = s.heightmap_filename.strip()
        if heightmap_filename:
            # Find the heightmap in the crops
            heightmap_crop_path = root / "sections" / sec_id / "crops" / heightmap_filename
            if heightmap_crop_path.exists():
                try:
                    hm_img = imaging.load_image(heightmap_crop_path)
                    hm_pixels = hm_img.pixels
                    if hm_pixels.ndim == 3:
                        # Use first channel for greyscale
                        hm_pixels = hm_pixels[:, :, 0]
                    
                    # Upscale effective mask to match crop size for masking
                    mask_for_hm = imaging.resize_double_bilinear(effective_mask[..., None])[:, :, 0]
                    # Clamp to heightmap size
                    mask_for_hm = mask_for_hm[:hm_pixels.shape[0], :hm_pixels.shape[1]]
                    if mask_for_hm.shape[0] < hm_pixels.shape[0] or mask_for_hm.shape[1] < hm_pixels.shape[1]:
                        padded = np.zeros(hm_pixels.shape, dtype=np.float32)
                        padded[:mask_for_hm.shape[0], :mask_for_hm.shape[1]] = mask_for_hm
                        mask_for_hm = padded
                    
                    # Find min/max brightness only where mask > 0.5
                    valid_pixels = hm_pixels[mask_for_hm > 0.5]
                    if len(valid_pixels) > 0:
                        section_max_brightness = float(np.max(valid_pixels))
                        section_min_brightness = float(np.min(valid_pixels))
                    else:
                        section_max_brightness = float(np.max(hm_pixels))
                        section_min_brightness = float(np.min(hm_pixels))
                    
                    section_max_elevation_m = section_max_brightness * s.max_elevation_m
                    section_min_elevation_m = section_min_brightness * s.max_elevation_m
                    
                    elevation_info = {
                        "heightmap_file": heightmap_filename,
                        "global_max_elevation_m": s.max_elevation_m,
                        "section_max_brightness": round(section_max_brightness, 4),
                        "section_max_elevation_m": round(section_max_elevation_m, 2),
                        "section_min_brightness": round(section_min_brightness, 4),
                        "section_min_elevation_m": round(section_min_elevation_m, 2),
                    }
                    print(f"[Project-R] Heightmap: brightness={section_min_brightness:.2%}-{section_max_brightness:.2%}, elevation={section_min_elevation_m:.0f}-{section_max_elevation_m:.0f}m")
                except Exception as e:
                    print(f"[Project-R] Warning: Failed to analyze heightmap: {e}")
            else:
                print(f"[Project-R] Warning: Heightmap '{heightmap_filename}' not found in crops")
                self.report({"WARNING"}, f"Heightmap '{heightmap_filename}' not found in this section's crops; elevation not tracked")

        # Update source_maps in manifest
        manifest.setdefault("global", {})["source_maps"] = [f.name for f in source_maps]
        
        # Update global heightmap settings if specified
        if heightmap_filename:
            manifest["global"]["heightmap_filename"] = heightmap_filename
            manifest["global"]["max_elevation_m"] = s.max_elevation_m
        
        section_entry = {
            "id": sec_id,
            "name": s.new_section_name,
            "created_utc": dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z",
            "projection": {
                "type": "Hammer",
                "center_lon_deg": params.center_lon_deg,
                "center_lat_deg": params.center_lat_deg,
                "rot_deg": params.rot_deg,
            },
            "full_canvas": {
                "size": [full_w, full_h],
                "path_by_layer": full_paths,
            },
            "crop": {
                "used_square": bool(s.square_crop),
                "rect_xywh": [int(rect.x), int(rect.y), int(rect.w), int(rect.h)],
                "paths_by_layer": crop_paths,
            },
            "size_info": {
                "planet_radius_km": planet_radius_km,
                "extent_km": [round(extent_width_km, 2), round(extent_height_km, 2)],
                "km_per_pixel": round(km_per_pixel, 4),
                "crop_pixels": [rect.w, rect.h],
            },
            "processed": {"expected_paths_by_layer": {}},
            "masks": {
                "effective_mask_path": str(effective_rel).replace("\\", "/"),
                "resolution_scale": 0.5,
            },
            "reassembly": {
                "feather_px": int(s.feather_px),
            },
            "created_from_selection": {
                "mesh_object": context.active_object.name if context.active_object else "",
                "selected_face_indices": face_indices,
                "selection_uv_sample_count": len(lonlats),
            },
            "overlay_color_rgba": overlay_color_rgba,
        }
        
        # Add elevation info if available
        if elevation_info is not None:
            section_entry["elevation_info"] = elevation_info
        
        # Write the manifest exactly once, with planet_radius_km folded in, so an
        # interruption can't leave a section recorded without its global scale.
        manifest["global"]["planet_radius_km"] = planet_radius_km
        manifest.setdefault("sections", []).append(section_entry)
        manifest_lib.write_manifest(mp, manifest)

        # Silently export per-class Gaea masks for any categorical classification map
        # (Köppen / biome / geology / ...) that was uploaded into source/. These are
        # additional outputs reprojected into this section's exact crop; a failure here
        # never fails the section. section_entry carries the projection + crop geometry
        # the exporter needs.
        try:
            from .inputs_ops import export_section_class_masks
            mask_summary = export_section_class_masks(root, section_entry, source_maps)
            if mask_summary:
                total = sum(m["classes"] for m in mask_summary)
                print(f"[Project-R] Auto-exported {total} class mask(s) from "
                      f"{len(mask_summary)} categorical map(s) into sections/{sec_id}/masks/")
        except Exception as e:
            print(f"[Project-R] Warning: class-mask auto-export skipped: {e}")

        # Write human-readable section_info.txt
        created_utc = dt.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
        _write_section_info_txt(
            section_dir=root / "sections" / sec_id,
            section_name=s.new_section_name,
            created_utc=created_utc,
            planet_radius_km=planet_radius_km,
            extent_km=(extent_width_km, extent_height_km),
            km_per_pixel=km_per_pixel,
            projection_type="Hammer (oblique)",
            center_lon_deg=params.center_lon_deg,
            center_lat_deg=params.center_lat_deg,
            rot_deg=params.rot_deg,
            crop_pixels=(rect.w, rect.h),
            crop_position=(rect.x, rect.y),
            full_canvas_size=(full_w, full_h),
            square_crop=bool(s.square_crop),
            feather_px=int(s.feather_px),
            elevation_info=elevation_info,
        )
        
        # Make the just-created section the erosion target so the dropdown reflects
        # it without the user re-finding it.
        es = context.scene.projection_pasta_erosion
        try:
            es.section = sec_id
        except Exception:
            pass

        # Suggest the erosion/output resolution AUTO would use for this selection (its
        # share of the World Map Resolution target, or the balanced native size when the
        # target is on Auto) so the readout matches what an Auto erode will run at.
        suggested_res = erosion.resolve_section_output(
            "AUTO", native_long, world_long, str(s.target_world_resolution))
        self.report(
            {"INFO"},
            f"Created section '{s.new_section_name}' - {extent_width_km:.0f} x {extent_height_km:.0f} km "
            f"({km_per_pixel:.2f} km/pixel), crop {native_long}px (auto erode ≈{suggested_res}px)",
        )

        # Optionally erode it right away, targeting this exact id (no last-section
        # fallback). Skipped with a clear warning if landlab isn't installed.
        if es.erode_on_create:
            if deps.landlab_available():
                bpy.ops.pp.erode_section(section_override=sec_id)
            else:
                self.report(
                    {"WARNING"},
                    "Section created, but landlab isn't installed -- skipped erosion. "
                    "Click Install Dependencies.",
                )
        return {"FINISHED"}


_CLASSES = (PP_OT_create_section,)


def register() -> None:
    for c in _CLASSES:
        bpy.utils.register_class(c)


def unregister() -> None:
    for c in reversed(_CLASSES):
        bpy.utils.unregister_class(c)


